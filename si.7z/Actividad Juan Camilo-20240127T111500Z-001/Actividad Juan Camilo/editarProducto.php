<?php

require_once 'modelo/MySQL.php';
//capturo el dato 
$id = $_GET['id'];

$mysql = new MySQL();

$mysql->conectar();


$consulta = $mysql->efectuarConsulta("SELECT actividadjuancamilo.productos.nombre_producto,
actividadjuancamilo.productos.cantidad,
actividadjuancamilo.productos.imagen,
actividadjuancamilo.productos.estado,
actividadjuancamilo.productos.id_usuario
FROM actividadjuancamilo.productos WHERE id_producto= $id");


$fila = mysqli_fetch_array($consulta);

$mysql->desconectar();

?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="./assets/css/bootstrap.min.css">
    <title>Document</title>
</head>

<body>

    <div class="container">
        <div class="row">
            <div class="col-6">
                <br>
                <br>
                <h1>Pagina para Editar Productos</h1>
                <br>
                <form action="controlador/guardarEditar.php" method="post">
                    <div class="mb-3">
                        <input type="hidden" class="form-control" name="id" value="<?php echo $id ?>" <label for="exampleInputPassword1" class="form-label">Nuevo Nombre del Producto</label>
                        <input type="text" class="form-control" name="nombre" value="<?php echo $fila['nombre_producto'] ?>" id="nombre">
                    </div>
                    <div class="mb-3">
                        <label for="exampleInputEmail1" class="form-label">Nueva Cantidad del Producto</label>
                        <input type="text" class="form-control" name="cantidad" value="<?php echo  $fila['cantidad'] ?>" id="cantidad" aria-describedby="emailHelp">
                    </div>
                    <div class="mb-3">
                        <label for="exampleInputPassword1" class="form-label">Nuevo Estado<strong>("Activo" ó "Inactivo")</strong> </label>
                        <input type="text" class="form-control" name="estado" value="<?php echo $fila['estado'] ?>" id="estado">
                    </div>
                    <div class="mb-3">
                        <label for="exampleInputEmail1" class="form-label">Id de la persona quien agrego este producto</label>
                        <input type="text" readonly="" class="form-control" name="idUsuario" value="<?php echo $fila['id_usuario'] ?>" id="idUsuario" aria-describedby="emailHelp">
                    </div>
                    <div class="mb-3">
                        <label for="exampleInputPassword1" class="form-label">Nuevo Link de la imagen del producto</label>
                        <input type="text" class="form-control" name="imagen" value="<?php echo $fila['imagen'] ?>" id="imagen">
                    </div>


                    <button type="submit" class="btn btn-primary">Actualizar</button>

                </form>
                <br>
                <form action="./agregarProducto.php">
                    <button type="submit" class="btn btn-danger">Atras</button>
                </form>
            </div>
        </div>
    </div>

</body>

</html>