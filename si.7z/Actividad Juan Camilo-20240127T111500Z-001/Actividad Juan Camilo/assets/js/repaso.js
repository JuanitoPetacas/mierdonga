let adso = [];
adso.push("narva","alejo");
console.log(adso);
adso.shift();
console.log(adso);



let equipos = ["Cali","Bucaramanga","Cucuta","Pasto"]
//recorrer tradicional 
for (let index = 0; index < equipos.length; index++) {
 console.log(array[index]);
    
}
//recorrer mas usado
 equipos.forEach((equipo) => {
    console.log(equipo); 
});

//nuevo arreglo 
let pares = [2,3,4,5]
let arregloNuevo= pares.map((par)=>{
    console.log(par+1)
})