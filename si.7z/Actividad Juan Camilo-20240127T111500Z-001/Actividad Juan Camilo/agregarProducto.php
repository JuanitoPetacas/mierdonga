<?php
require_once './modelo/usuarios.php';
require_once './modelo/MySQL.php';
$mySql  = new MySQL();
session_start();
$usuarios = new usuarios();
$usuarios = $_SESSION['usuario'];
$id = $usuarios->getId();

$mySql->conectar();

$consulta = $mySql->efectuarConsulta("SELECT actividadjuancamilo.productos.id_producto ,
actividadjuancamilo.productos.nombre_producto ,
actividadjuancamilo.productos.cantidad ,
actividadjuancamilo.productos.estado ,
actividadjuancamilo.productos.id_usuario ,
actividadjuancamilo.productos.imagen
 FROM actividadjuancamilo.productos ");


$mySql->desconectar();

?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="./assets/css/bootstrap.min.css">
    <title>Document</title>
</head>

<body>

    <main>
        <div class="container-fluid">
            <div class="row">
                <div class="col-6">
                    <br>
                    <br>
                    <h1>Pagina Agregar Productos</h1>
                    <form action="controlador/agregar.php" method="Post">
                        <div class="mb-3">

                            <label for="exampleInputEmail1" class="form-label">Nombre</label>
                            <input type="text" class="form-control" id="exampleInputEmail1" name="nombre">
                        </div>
                        <div class="mb-3">
                            <label for="exampleInputPassword1" class="form-label">Cantidad</label>
                            <input type="text" class="form-control" id="exampleInputPassword1" name="cantidad">
                        </div>
                        <div class="mb-3">
                            <label for="exampleInputPassword1" class="form-label">Imagen del producto (link)</label>
                            <input type="text" class="form-control" id="exampleInputPassword1" name="imagen">
                        </div>
                        <input type="hidden" class="form-control" value="<?php echo $id; ?>" id="id" name="id">
                        <button type="submit" class="btn btn-success">Agregar</button>

                    </form>
                </div>
            </div>
            <div class="row">
                <div class="col-10">
                    <table class="table">
                        <thead>
                            <tr>
                                <th></th>
                                <th scope="col">Id</th>
                                <th scope="col">Nombre</th>
                                <th scope="col">Cantidad</th>
                                <th scope="col">Estado</th>
                                <th scope="col">Agrego el usuario con ID</th>
                                <th scope="col">Imagen</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php while ($row = mysqli_fetch_array($consulta)) { ?>

                                <tr>
                                    <td>
                                        <form action="controlador/eliminar.php? id=<?php echo $row['id_producto'] ?>" method="post">
                                            <button type="submit" class="btn btn-danger">Eliminar</button>
                                        </form>
                                        <br>
                                        <form action="./editarProducto.php? id=<?php echo $row['id_producto'] ?>" method="post">
                                            <button type="submit" class="btn btn-primary">Editar</button>
                                        </form>
                                    </td>
                                    <td> <?php echo $row['id_producto'] ?></td>
                                    <td> <?php echo $row['nombre_producto'] ?></td>
                                    <td> <?php echo $row['cantidad'] ?></td>
                                    <td> <?php echo $row['estado'] ?></td>
                                    <td> <?php echo $row['id_usuario'] ?></td>
                                    <td> <img src="<?php echo $row['imagen'] ?>" width="80px" height="80px" alt=""></td>

                                </tr>

                            <?php } ?>
                        </tbody>
                    </table>
                    <form action="controlador/imprimir.php" method="post">
                        <button type="submit" class="btn btn-primary">imprimir</button>
                    </form>
                    <form action="index.php" method="post">
                        <button type="submit" class="btn btn-danger">Atras</button>
                    </form>

                </div>
            </div>
        </div>
    </main>


</body>

</html>