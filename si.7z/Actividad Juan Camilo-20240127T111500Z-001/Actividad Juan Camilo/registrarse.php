<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="./assets/css/bootstrap.min.css">

    <title>Document</title>
</head>
<body>
    
<main>
    <div class="container">
        <div class="row">
            <div class="col-2"></div>
            <div class="col-8">
                <br>
                <br>
                <h1>Pagina registro</h1>
                <form action="controlador/register.php" method="Post">
                    <div class="mb-3">
                        <label for="exampleInputEmail1" class="form-label">Correo</label>
                        <input type="email" class="form-control" id="exampleInputEmail1" name="correo">
                    </div>
                    <div class="mb-3">
                        <label for="exampleInputPassword1" class="form-label">Contraseña</label>
                        <input type="text" class="form-control" id="exampleInputPassword1" name="pass">
                    </div>
                    <div class="mb-3">
                        <label for="exampleInputPassword1" class="form-label">Estado<strong>("Activo" ó "Inactivo")</strong></label>
                        <input type="text" class="form-control" id="exampleInputPassword1" name="estado">
                    </div>
                    <button type="submit" class="btn btn-success">Registrarse</button>
              
                </form>
                <br>
                <form action="index.php">
                <button type="submit" class="btn btn-danger" >Cancelar</button>
                </form>
            </div>
            <div class="col-2"></div>
        </div>
    </div>
</main>



</body>
</html>